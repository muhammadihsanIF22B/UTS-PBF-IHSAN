<?php

namespace Database\Factories;

use App\Models\Product;
use Illuminate\Database\Eloquent\Factories\Factory;
use Illuminate\Support\Carbon;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\Product>
 */

class ProductFactory extends Factory
{
    protected $model = Product::class;

    public function definition()
    {
        $categories = ['Mesin Cuci', 'Kipas', 'Setrika'];
        $category = $this->faker->randomElement($categories);

        // Daftar merek mesin cuci
        $washingMachineBrands = [
            'LG',
            'Samsung',
            'Whirlpool',
            'Bosch',
            'Panasonic',
            'Electrolux',
            'Hitachi',
            'Sharp',
            'Midea',
            'Haier'
        ];

        // Daftar merek kipas
        $fanBrands = [
            'Miyako',
            'Panasonic',
            'Cosmos',
            'Sekai',
            'Maspion',
            'KDK',
            'National',
            'Regency',
            'Oxone',
            'Philips'
        ];

        // Daftar merek setrika
        $ironBrands = [
            'Philips',
            'Panasonic',
            'Maspro',
            'Cosmos',
            'Miyako',
            'Oxone',
            'Black+Decker',
            'Sharp',
            'Hitachi',
            'Electrolux'
        ];

        $name = $category == 'Mesin Cuci'
            ? $this->faker->randomElement($washingMachineBrands)
            : ($category == 'Kipas'
                ? $this->faker->randomElement($fanBrands)
                : $this->faker->randomElement($ironBrands));

        $description = $category == 'Mesin Cuci'
            ? $this->faker->randomElement([
                'Mesin cuci dengan teknologi mutakhir.',
                'Membersihkan pakaian dengan efisiensi tinggi.',
                'Hemat energi dan ramah lingkungan.'
            ])
            : ($category == 'Kipas'
                ? $this->faker->randomElement([
                    'Kipas angin dengan hembusan angin kencang.',
                    'Desain elegan dan modern.',
                    'Hemat energi dan tahan lama.'
                ])
                : $this->faker->randomElement([
                    'Setrika dengan panas cepat dan merata.',
                    'Desain ergonomis dan mudah digunakan.',
                    'Hemat energi dan hasil setrika rapi.'
                ]));

        return [
            'name' => $name,
            'description' => $description,
            'price' => $this->faker->numberBetween(100000, 5000000),
            'image' => $this->faker->imageUrl(640, 480, 'product', true),
            'category_id' => $category == 'Mesin Cuci' ? 1 : ($category == 'Kipas' ? 2 : 3),
            'expired_at' => now()->addDays(365),
            'modified_by' => $this->faker->randomElement(['user@gmail.com', 'ihsan@gmail.com'])
        ];
    }
}
